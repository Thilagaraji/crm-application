import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

function ProtectedRoute({ children, allowedRoles }) {
  const { user, role, loading } = useAuth();

  // wait until auth check finishes
  if (loading) {
    return <div>Loading...</div>;
  }

  // if not logged in
  if (!user) {
    return <Navigate to="/login" />;
  }

  // if role not allowed
  if (!allowedRoles.includes(role)) {
    return <Navigate to="/" />;
  }

  return children;
}

export default ProtectedRoute;