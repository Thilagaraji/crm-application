import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import TeamDashboard from "./pages/TeamDashboard/TeamDashboard";
import SalesPipeline from "./pages/SalesPipeline/SalesPipeline";
import TaskReminders from "./pages/TaskReminders/TaskReminders";

import MainLayout from "./layouts/MainLayout";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <Router>

      <Routes>

        {/* Default route → redirect to login */}
        <Route path="/" element={<Navigate to="/login" />} />

        {/* Public Route */}
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>

          <Route element={<MainLayout />}>

            {/* Dashboard */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute allowedRoles={["admin", "sales", "user"]}>
                  <TeamDashboard />
                </ProtectedRoute>
              }
            />

            {/* Sales Pipeline */}
            <Route
              path="/pipeline"
              element={
                <ProtectedRoute allowedRoles={["admin", "sales"]}>
                  <SalesPipeline />
                </ProtectedRoute>
              }
            />

            {/* Task Reminder */}
            <Route
              path="/tasks"
              element={
                <ProtectedRoute allowedRoles={["admin", "user"]}>
                  <TaskReminders />
                </ProtectedRoute>
              }
            />

          </Route>

        </Route>

      </Routes>

    </Router>
  );
}

export default App;